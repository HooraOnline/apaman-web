const animations = {
  splash: require('./animations/splash_lottie.json'),
};
export default animations;
