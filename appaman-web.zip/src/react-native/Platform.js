import View from "./View";
import Keyboard from "./Keyboard";

const Platform={
    OS:'android',
}

export default Platform;
