const Keyboard={
    dismiss:function () {
       //close Keyboard in mobile
    }
}

export default Keyboard;
