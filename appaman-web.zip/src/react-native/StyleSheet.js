const StyleSheet={
    create:function (style) {
        return style;
    }
}

export default StyleSheet;
