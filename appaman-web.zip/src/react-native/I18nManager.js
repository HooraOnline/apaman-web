import Easing from "./Easing";

const I18nManager={
    isRTL:false,
    allowRTL:function (rtl) {

    },
    forceRTL:function (rtl) {

    },

}

export default I18nManager;
