 const Easing={
    out:1,
}
 export default Easing;
