
export default
    /*------Android Version-------*/
    // {name: 'bazzar', release: true}
    // {name: 'myket', release: true}

    {name: 'apamanSite', release: true}
    // {name: 'apamanSite', release: false}


    /*------IOS Version-------*/
    // {name: 'sibApp', release: true}
    // {name: 'anardoni', release: true}
    // {name: 'iapps', release: true}
