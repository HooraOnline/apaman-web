export default {
  colors: {
    primary: '#003648'
  }
}
