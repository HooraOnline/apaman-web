
import * as publicActions from './publicActions';
import * as userActions from './userActions';
export const ActionCreators = Object.assign({},
  publicActions,
  userActions,
);

