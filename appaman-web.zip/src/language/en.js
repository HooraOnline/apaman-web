global.isRtl=false
export const en={
  "en_welcome_to_app": "Welcome to Apaman",
  "en_enter_your_phone_number": "Enter your phone number",
  "en_example": "Example 09123445566",
  "en_password": "Password",
  "en_login": "Login"
}
