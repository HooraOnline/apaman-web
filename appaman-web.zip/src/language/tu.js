global.isRtl=true

export const tu={
  "tu_welcome_to_app": "Apaman'a Hoşgeldiniz",
  "tu_enter_your_phone_number": "Giriş yapmak için numaranızı girin.",
  "tu_example": "Örnek 09123467655",
  "tu_password": "şifre",
  "tu_login": "giriş"
}
