global.isRtl=true
export const fa= {
  "fa_welcome_to_app": "به اپامن خوش آمدید",
  "fa_enter_your_phone_number": "برای ورود شماره خود را وارد کنید.",
  "fa_example": "مثال ۰۹۱۲۳۴۵۶۶۷۷",
  "fa_password": "رمز عبور",
  "fa_login": "ورود"
}
