global.isRtl=true
export const ch= {
  "ch_welcome_to_app": "欢迎来到 Apaman",
  "ch_enter_your_phone_number": "输入您的号码以登录。",
  "ch_example": "示例09196425563",
  "ch_password": "密码",
  "ch_login": "登入"
}
