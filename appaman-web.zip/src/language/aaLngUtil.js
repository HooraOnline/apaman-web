import {fa} from "./fa";
export const LNGList=[
    {index:0,title: 'فارسی',key:'fa',rtl:true},
    {index:1,title: 'English',key:'en',rtl:false},
    {index:2,rtl:true,key:'ar',title: 'العربیه'},
    /*{index:3,title:'中文语言',key:'ch',rtl:false}*/,
    {index:4,title:'Türk',key:'tu',rtl:false}
];


