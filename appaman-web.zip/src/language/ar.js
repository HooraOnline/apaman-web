global.isRtl=false
export const ar= {
  "ar_welcome_to_app": "مرحبا بكم في اپامن",
  "ar_enter_your_phone_number": "أدخل رقم هاتفك المحمول.",
  "ar_example": "مثل ۰۹۱۲۳۴۵۶۶۷۷",
  "ar_password": "كلمة المرور",
  "ar_login": "تسجيل الدخول"
}
