import React, { PureComponent } from 'react'
import Link from 'next/link'

export default class Layout extends PureComponent {
  // Create the keyframes




  render () {


    return (
        <>

            { this.props.children }

        </>

    )
  }
}
