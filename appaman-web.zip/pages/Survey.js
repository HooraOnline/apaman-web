// pages/mycart.js

import MobileLayout from "../src/components/layouts/MobileLayout";

const Survey = props => <MobileLayout title={`نظر سنجی`}>{`نظر سنجی`}</MobileLayout>;

export default Survey;
