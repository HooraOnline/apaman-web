// pages/mycart.js

import PanelLayout from "../src/components/layouts/panelLayout";

const Rules = props => <MobileLayout title={`قوانین ساختمان`}>{`قوانین ساختمان `}</MobileLayout>;

export default Rules;
