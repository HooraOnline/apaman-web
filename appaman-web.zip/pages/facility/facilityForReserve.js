// pages/mycart.js

import MobileLayout from "../../src/components/layouts/MobileLayout";

const FacilityForReserve = props => <MobileLayout title={`رزرو امکان رفاهی`}>{`رزرو امکان رفاهی`}</MobileLayout>;

export default FacilityForReserve;
