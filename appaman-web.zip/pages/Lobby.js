// pages/mycart.js

import MobileLayout from "../src/components/layouts/MobileLayout";

const Lobby = props => <MobileLayout title={`تماس با لابی`}>{`تماس با لابی`}</MobileLayout>;

export default Lobby;
