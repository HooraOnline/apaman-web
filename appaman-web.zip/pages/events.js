// pages/profile.js

import MobileLayout from "../src/components/layouts/MobileLayout";

const Events = props => <MobileLayout title={`رخدادها`} >{`رخدادها`}</MobileLayout>;

export default Events;
