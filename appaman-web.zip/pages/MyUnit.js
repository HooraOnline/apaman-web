// pages/mycart.js

import MobileLayout from "../src/components/layouts/panelLayout";

const MyUnit = props => <MobileLayout title={`واحد من`}>{`واحد من`}</MobileLayout>;

export default MyUnit;
