// pages/mycart.js

import MobileLayout from "../src/components/layouts/MobileLayout";

const ContactUs = props => <MobileLayout title={`هیات مدیره`}>{`هیئت مدیره`}</MobileLayout>;

export default ContactUs;
